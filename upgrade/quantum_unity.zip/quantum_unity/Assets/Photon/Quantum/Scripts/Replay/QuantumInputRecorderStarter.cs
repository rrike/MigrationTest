﻿using UnityEngine;

[System.Obsolete("Inputs are now recorded with QuantumGame.StartRecordingReplay.")]
public class QuantumInputRecorderStarter : MonoBehaviour { }

